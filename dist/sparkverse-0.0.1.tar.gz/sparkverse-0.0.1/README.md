# SparkVerse
Simulator for Computer Vision Applications
