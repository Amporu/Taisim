from setuptools import setup,find_packages

setup(
name='sparkverse',
version='0.0.1',
description='simulator for computer vision aplications',
packages=find_packages(),







)