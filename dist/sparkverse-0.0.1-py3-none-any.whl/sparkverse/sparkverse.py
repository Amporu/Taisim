def hello():
    print("Miiiiii")