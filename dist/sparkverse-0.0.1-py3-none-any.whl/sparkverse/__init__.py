def hello():
    print("mi")